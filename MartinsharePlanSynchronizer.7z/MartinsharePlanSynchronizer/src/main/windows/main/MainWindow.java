package main.windows.main;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import main.Main;
import main.components.Data;
import main.components.DirWatcher;
import main.components.UploadTimer;
import org.joda.time.DateTime;

import java.io.IOException;

/**
 * Lädt das Layout und setzt den Controller
 */
public class MainWindow {
    private Scene scene;
    public MainController controller;

    public MainWindow() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("mainWindow.fxml"));
            loader.setController(controller = new MainController());
            scene = new Scene(loader.load(), 590, 200);

            if(Data.loadData().getActive() && controller.isDirectory(Data.loadData().getSyncpath())) {
                Main.getInstance().hideMain(Main.getInstance().window);

                UploadTimer.uploadWholeDirectoryTimer(Data.loadData().getSyncpath(), controller);
                controller.getDirWatcher().startWatching();


            } else {
                Data.setActive(false);
            }

            controller.updateUI();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Scene getScene() {
        return scene;
    }


}
