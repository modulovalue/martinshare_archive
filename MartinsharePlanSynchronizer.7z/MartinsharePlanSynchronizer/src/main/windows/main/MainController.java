package main.windows.main;

import com.sun.deploy.uitoolkit.impl.fx.HostServicesFactory;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.effect.GaussianBlur;
import javafx.scene.image.ImageView;
import main.*;
import main.components.*;
import main.interfaces.onWatching;
import org.joda.time.DateTime;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.util.function.Function;

/**
 * Controller des Hauptfensters.
 *
 */
public class MainController implements onWatching {

    private DirWatcher dirWatcher;

    @FXML private Label activelbl;
    @FXML private Label keylbl;
    @FXML private Label datelbl;
    @FXML private Label versionlbl;
    @FXML private Label dirlbl;
    @FXML private Label dirlbl2;
    @FXML private Label schoollbl;
    @FXML private Label homepagelbl;
    @FXML private Button activatebtn;
    @FXML private Button dirbtn;
    @FXML private CheckBox minchk;
    @FXML private ImageView imageview;

    //Minimierungs CheckBox
    @FXML private void checkclick() { Data.setShowMinimizeNotification(minchk.isSelected()); }
    @FXML private void openmartinshare() { HostServicesFactory.getInstance(Main.getInstance()).showDocument(Info.homepage); }
    @FXML private void emailclick() { HostServicesFactory.getInstance(Main.getInstance()).showDocument("mailto:" + Info.contact); }
    @FXML private void onImageHover()    { imageview.setEffect(new GaussianBlur(0)); }
    @FXML private void onImageNotHover() { imageview.setEffect(new GaussianBlur(9)); }

    @FXML
    private void directoryBtn() {
        Main.getInstance().window.hide();
        Data.setSyncpath(DirectoryChooser.getDirectory());
        updateUI();
        Main.getInstance().window.show();
    }

    @FXML
    private void activatebtn() {
        if (isDirectory(Data.loadData().getSyncpath())) {
            if(!Data.loadData().getActive()) {
                Data.setActive(true);
                getDirWatcher().startWatching();
                UploadTimer.uploadWholeDirectoryTimer(Data.loadData().getSyncpath(), MainController.this);

            } else {

                Data.setActive(false);

                getDirWatcher().stopWatching();
            }
        } else {
            Data.setActive(false);
            getDirWatcher().stopWatching();
            JOptionPane.showMessageDialog(null, "Fehlerhaftes Verzeichnis");
        }

        updateUI();
    }

    @FXML
    private void logoutbtn() {
        getDirWatcher().stopWatching();
        Main.getInstance().hideTray().showLogin();
        Data.writeData(new Data());
    }

    public boolean isDirectory(String path) {
        if (new File(path).isDirectory()) {
            dirlbl.setText(path);
            dirlbl2.setText(path);
            return true;
        } else {
            String fehler = "Fehlerhaftes Verzeichnis";
            dirlbl.setText(fehler);
            dirlbl2.setText(fehler);
            return false;
        }
    }

    public void updateUI() {

        System.out.println("UI WURDE AKTUALISIERT");
        Data d = Data.loadData();

        isDirectory(d.getSyncpath());

        dirbtn.setDisable(Data.loadData().getActive());
        minchk.setSelected(d.getShowMinimizeNotification());
        schoollbl.setText(d.getSchulname());
        homepagelbl.setText(d.getHomepage());
        versionlbl.setText(Info.version);

        // Key Label wird beschriftet
        String temp = "";
        for(int i = 0; i < d.getKey().length()-8; i++) {
                temp += "x";
        }
        keylbl.setText(d.getKey().substring(0, 4) + temp + d.getKey().substring(d.getKey().length()-4,d.getKey().length()));


        //Date Label wird beschriftet
        DateTime dt = d.getZuletztAktualisiert();
        if(dt.getYear() < 2000) {
            datelbl.setText("Nie");
        } else {
            datelbl.setText(dt.getDayOfMonth() + "." + dt.getMonthOfYear() + "." + dt.getYear() + " " + dt.getHourOfDay() + ":" + dt.getMinuteOfHour() + ":" + dt.getSecondOfMinute());
        }


        //Aktivierungsbutton wird beschriftet
        activatebtn.setText( d.getActive() ? "Deaktivieren" : "Aktivieren");

    }

    public DirWatcher getDirWatcher() {
        if(dirWatcher == null) {
            dirWatcher = new DirWatcher(Data.loadData().getSyncpath(), this);
        }
        return dirWatcher;
    }


    public void startedWatching() {
        Platform.runLater(() -> {
            activelbl.setText("Aktiv, Ordner wird beobachtet");
        });
        LogData.writeLogFile("Beobachtung wurde begonnen");
    }

    @Override
    public void startWatching() {
        LogData.writeLogFile("Polling Scan Beginn");
    }

    @Override
    public void stopWatching() {
        LogData.writeLogFile("Polling Scan Ende");
    }

    @Override
    public void onUploaded() {
        Platform.runLater(() -> {
            activelbl.setText("Aktiv, Ordner wird beobachtet");
            Main.getInstance().trayIcon.displayMessage("Erfolg", "Pläne wurden erfolgreich Synchronisiert.", TrayIcon.MessageType.INFO);
            Data.setZuletztAktualisiert(DateTime.now());
            MainController.this.updateUI();
        });
        LogData.writeLogFile("Pläne wurden erfolgreich Synchronisiert.");
    }

    @Override
    public void startUploading() {
        Platform.runLater(() -> {
            activelbl.setText("Synchronisation läuft...");
            Main.getInstance().trayIcon.displayMessage("Synchronisation läuft...", "Pläne werden Synchronisiert.", TrayIcon.MessageType.INFO);
        });

        LogData.writeLogFile("Synchronisation läuft..."+ "Pläne werden Synchronisiert.");
    }

    @Override
    public void onUploadFailed() {
        Platform.runLater(() -> {
            Main.getInstance().trayIcon.displayMessage("Aktualisierung fehlgeschlagen", "Die Aktualisierung ist fehlgeschlagen", TrayIcon.MessageType.ERROR);
        });

        LogData.writeLogFile("Aktualisierung fehlgeschlagen" + "Die Aktualisierung ist fehlgeschlagen");
    }

    @Override
    public void eventHappened(String string) {
        System.out.println(string);
        LogData.writeLogFile(string);
    }

    @Override
    public void stoppedWatching() {
        Platform.runLater(() -> {
            activelbl.setText("Deaktiviert, ordner wird nicht synchronisiert");
        });
        LogData.writeLogFile("Beobachtung wurde beendet");
    }

}
