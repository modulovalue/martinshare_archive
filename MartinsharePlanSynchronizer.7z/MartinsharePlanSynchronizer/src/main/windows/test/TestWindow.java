package main.windows.test;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;

import java.io.IOException;

/**
 * Created by Modestas Valauskas on 21.05.2015.
 */
public class TestWindow {

    private Scene scene;
    public TestController controller;

    public TestWindow() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("testWindow.fxml"));
            loader.setController(controller = new TestController());
            scene = new Scene(loader.load());

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Scene getScene() {
        return scene;
    }
}
