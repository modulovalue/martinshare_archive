package main.windows.test;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.text.Text;
import main.Main;
import main.MartinshareAPI;
import main.components.DirWatcher;
import main.components.DirectoryChooser;
import main.components.UploadTimer;
import main.interfaces.onWatching;
import org.joda.time.DateTime;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Objects;

/**
 * Created by Modestas Valauskas on 21.05.2015.
 */
public class TestController {

    @FXML private TextArea debugArea;
    @FXML private Label timerTestLbl;
    @FXML private Label directoryChooserLbl;
    @FXML private Label checkStatusLbl;
    @FXML private Label deleteFilesFromServerLbl;

    private DirWatcher watcher;


    private onWatching onWatching = new onWatching() {
        @Override
        public void startedWatching() {
            Platform.runLater(() -> debugArea.appendText("STARTED Watching: " + DateTime.now() + "\n"));
        }
        @Override
        public void startWatching() {
            Platform.runLater(() -> debugArea.appendText("Start Watching: " + DateTime.now() + "\n"));
        }

        @Override
        public void stopWatching() {
            Platform.runLater(() -> debugArea.appendText("Stop Watching: " + DateTime.now() + "\n"));
        }

        @Override
        public void startUploading() {
            Platform.runLater(() -> debugArea.appendText("Start Uploading" + "\n"));
        }

        @Override
        public void onUploaded() {
            Platform.runLater(() -> {
                debugArea.appendText("Hochgeladen" + "\n");
            });
        }

        @Override
        public void onUploadFailed() {
            Platform.runLater(() -> {
                debugArea.appendText("Hochgeladen fehlgeschlagen" + "\n");
            });
        }

        @Override
        public void eventHappened(String string) {
            Platform.runLater(() -> debugArea.appendText(string + "\n"));
        }

        @Override
        public void stoppedWatching() {
            Platform.runLater(() -> debugArea.appendText("STOPPED Watching" + DateTime.now() + "\n"));
        }
    };

    private String directory;

    @FXML
    private void trayBubbleTest() {
        Main.getInstance().trayIcon.displayMessage("Test", "Tray Bubble Test", TrayIcon.MessageType.INFO);
        debugArea.appendText("Tray Bubble" + "\n");
    }

    @FXML
    private void timerTest() {
      //  debugArea.appendText("Timer Test" + "\n");
      //  UploadTimer.timerTest(timerTestLbl);
    }

    @FXML
    private void directoryChooser() {
        directory = DirectoryChooser.getDirectory();
        directoryChooserLbl.setText(directory);
        watcher = new DirWatcher(directory, onWatching);
        debugArea.appendText("Verzeichnis: " + directory + "\n");
    }

    @FXML
    private void listFiles() {
        try {
            Files.walk(Paths.get(directory)).forEach(filePath -> {

                if (Files.isRegularFile(filePath)){
                    String extension = "";
                    int i = filePath.getFileName().toString().lastIndexOf('.');
                    if (i > 0) {
                        extension = filePath.getFileName().toString().substring(i+1);
                    }
                    if(Objects.equals(extension, "htm")) {
                        debugArea.appendText("HTM ENDUNG: " + filePath.getFileName() + "\n");
                    } else {
                        debugArea.appendText("ANDERE ENDUNG: " + filePath.getFileName() + "\n");
                    }

                } else {
                    debugArea.appendText("Not a Regular File " + filePath + "\n");
                }

            });

        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Exception List Files");
            debugArea.appendText("Exception List Files" + "\n");
        }

    }

    @FXML
    private void activateObserver() {
        watcher.startWatching();
        debugArea.appendText("Observer Aktiviert" + "\n");
    }

    @FXML
    private void deactivateObserver() {
        watcher.stopWatching();
        debugArea.appendText("Observer Deaktiviert" + "\n");
    }

    @FXML
    private void checkStatus() {
       // String status = MartinshareAPI.getStatus()+"";
       // checkStatusLbl.setText(status);
       // debugArea.appendText("Check Status: " + status + "\n");
    }

    @FXML
    private void deleteFilesFromServer() {
      //  String status = MartinshareAPI.serverDelete() +"";
      //  deleteFilesFromServerLbl.setText(status);
      //  debugArea.appendText("Delete From Server Status: " + status + "\n");
    }
    @FXML
    private void uploadFilesInDirectory() {
        MartinshareAPI.ordnerHochladen(directory, onWatching);
    }

}


