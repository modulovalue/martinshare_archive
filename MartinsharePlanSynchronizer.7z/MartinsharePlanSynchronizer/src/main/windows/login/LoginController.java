package main.windows.login;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import main.Main;
import main.MartinshareAPI;
import main.interfaces.ConnectionInterface;

/**
 * Controller des Loginfensters.
 */
public class LoginController {

    @FXML private PasswordField keyfield;
    @FXML private Label statuslabel;

    @FXML
    private void check() {
        statuslabel.setText("Wird geprüft,,,");
        MartinshareAPI.check(keyfield.getText(), new ConnectionInterface() {
            @Override
            public void noInternetConnection() {
                setInfoText("Fehler, Bitte versuche es später nochmal. (Keine Internetverbindung ?)");
            }

            @Override
            public void success() {
                setInfoText("Richtiger Key");
                Main.getInstance().loginWindow = null;
                Main.getInstance().showMain();
            }

            @Override
            public void wrongKey() {
                setInfoText("Falscher Key");
            }
        });
    };


    public void setInfoText(String msg) {
        Platform.runLater(() -> statuslabel.setText(msg));
    }

}
