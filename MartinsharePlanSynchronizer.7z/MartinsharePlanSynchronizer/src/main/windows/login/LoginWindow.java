package main.windows.login;


import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;

import java.io.IOException;

/**
 * Lädt das Layout und setzt den Controller
 */
public class LoginWindow {
    private Scene scene;
    private LoginController controller;

    public LoginWindow() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("authentication.fxml"));
            controller = new LoginController();
            loader.setController(controller);
            scene = new Scene(loader.load(), 600, 210);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public Scene getScene() {
        return scene;
    }

}
