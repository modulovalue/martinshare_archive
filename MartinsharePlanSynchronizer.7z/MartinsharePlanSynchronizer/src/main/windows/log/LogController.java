package main.windows.log;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import main.components.LogData;

import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by Modestas Valauskas on 25.05.2015.
 */
public class LogController {

    @FXML TextArea logArea;

    Timer timer;

    @FXML
    public void deleteLog() {
        LogData.deleteLogFile();
    }

    public LogController() {
        if (timer == null) {
            timer = new Timer();
            timer.scheduleAtFixedRate(new TimerTask() {
                @Override
                public void run() {

                    Platform.runLater(() -> {
                        logArea.setText(LogData.readLogFile());
                        logArea.setScrollTop(Double.MAX_VALUE);
                    });
                }
            },0 ,500);
        }
    }
}
