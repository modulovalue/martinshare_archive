package main.windows.log;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import main.windows.login.LoginController;

import java.io.IOException;

/**
 * Created by Modestas Valauskas on 25.05.2015.
 */
public class LogWindow {

    private Scene scene;
    private LogController controller;

    public LogWindow() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("logWindow.fxml"));
            controller = new LogController();
            loader.setController(controller);
            scene = new Scene(loader.load());

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Scene getScene() {
        return scene;
    }

}
