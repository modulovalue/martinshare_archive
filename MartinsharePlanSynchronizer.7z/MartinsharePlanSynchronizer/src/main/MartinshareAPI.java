package main;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.async.Callback;
import com.mashape.unirest.http.exceptions.UnirestException;
import javafx.application.Platform;
import main.components.Data;
import main.interfaces.ConnectionDeleteInterface;
import main.interfaces.ConnectionInterface;
import main.interfaces.onWatching;
import main.components.GetProxy;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Objects;

/**
 * Created by Modestas Valauskas on 08.04.2015.
 */
public class MartinshareAPI {

    private static String checkURL = "http://martinshare.com/api/vertretungsplan.php/check";
    private static String deleteURL = "http://martinshare.com/api/vertretungsplan.php/delete";
    private static String uploadURL = "http://martinshare.com/api/vertretungsplan.php/upload";
    public static String statusURL = "http://martinshare.com/api/vertretungsplan.php/status";


    public static int pufferZeit = 2;

    public static int uploadCounter = 0;
    public static int uploadCounterShould = 10000;
    public static int uploadsDid = 0;
    public static int uploadsDidShould = 0;

    /* eine Datei mit dem Pfad "filepath" wird Hochgeladen. */
    private static void upload(String filePath, Runnable allUploadSuccess, Runnable allUploadFailed) {

        uploadsDid++;

            Unirest.post(uploadURL)
                    .field("Key", Data.loadData().getKey())
                    .field("file", new File(filePath))
                    .asStringAsync(new Callback<String>() {
                        public void failed(UnirestException e) {
                            System.out.println(filePath + " upload failed");
                            uploadCounter-=uploadCounterShould;
                            uploadEnd(allUploadSuccess,allUploadFailed);
                        }

                        public void completed(HttpResponse<String> response) {
                            int code = response.getStatus();
                            if (code == 200) {
                                System.out.println(filePath + " OK");
                                uploadCounter++;
                                uploadEnd(allUploadSuccess,allUploadFailed);
                            } else if (code == 401) {
                                System.out.println("WRONG KEY");
                                uploadCounter-=uploadCounterShould;
                                uploadEnd(allUploadSuccess,allUploadFailed);
                            }
                        }

                        public void cancelled() {
                            System.out.println("The request has been cancelled");
                            uploadCounter-=uploadCounterShould;
                            uploadEnd(allUploadSuccess,allUploadFailed);
                        }

                    });
    }

    public static void uploadEnd(Runnable success, Runnable failed) {
        System.out.println(uploadCounter +" "+ uploadCounterShould+ "  " + uploadsDid + " " + uploadsDidShould);
        if(uploadsDid == uploadsDidShould) {
            if(uploadCounter == uploadCounterShould) {
                success.run();
                System.out.println("RUN MOFO");
            } else if(uploadCounter < 1) {
                failed.run();
            }
        }
    }

    /*
    * Dateien werden auf dem Externen Server gelöscht
    * Der Aufrufer dieser Methode muss sich um verschiede Statuscodes kümmern.
    * 200: Dateien erfolgreich gelöscht
    * 304: es wurden Dateien vor einer kurzen Zeit hochgeladen -> später nochmal versuchen ( um das Hochladen von 2 PC's gleichzeitig zu kontrollieren)
    * 0: es besteht keine Internetverbindung
    */
    public static void serverDelete(ConnectionDeleteInterface connection) {
        GetProxy.setProxyConnection();

            Unirest.post(deleteURL)
                    .field("Key", Data.loadData().getKey())
                    .asStringAsync(new Callback<String>() {

                        public void failed(UnirestException e) {
                            Platform.runLater(connection::noInternetConnection);
                        }

                        public void completed(HttpResponse<String> response) {
                            int code = response.getStatus();
                            if (code == 200) {
                                Platform.runLater(connection::success);
                            } else if (code == 401) {
                                Platform.runLater(connection::wrongKey);
                            } else if (code == 304) {
                                Platform.runLater(connection::zuletztAktualisiert);
                            }
                        }

                        public void cancelled() {
                            System.out.println("The request has been cancelled");
                        }
                    });
    }

    /* Hier wird der Key beim Einloggen überprüft. */
    public static void check(String key, ConnectionInterface connection) {
        GetProxy.setProxyConnection();
        Unirest.post(checkURL)
            .field("Key", key)
            .asStringAsync(new Callback<String>() {

                               public void failed(UnirestException e) {
                                   Platform.runLater(connection::noInternetConnection);
                               }

                               public void completed(HttpResponse<String> response) {
                                   int code = response.getStatus();
                                   if (code == 200) {
                                       Data.setHomepage(response.getHeaders().getFirst("homepage"));
                                       Data.setKey(key);
                                       Data.setSchulname(response.getHeaders().getFirst("schule"));
                                       Platform.runLater(connection::success);
                                   } else if (code == 401) {
                                       Platform.runLater(connection::wrongKey);
                                   }
                               }

                               public void cancelled() {
                                   System.out.println("The request has been cancelled");
                               }
                           }
            );
    }


    /*
     * Lädt alle Dateien mit der Endung "htm"  hoch.
     */

    public static void ordnerHochladen(String path, onWatching watching){

        String fileending = "htm";
        System.out.println("ORDNER HOCHLADEN");
        try {
            MartinshareAPI.uploadCounter = 0;
            MartinshareAPI.uploadsDid = 0;
            MartinshareAPI.uploadCounterShould = 0;
            MartinshareAPI.uploadsDidShould = 0;

            Files.walk(Paths.get(path)).forEach(filePath -> {
                if (Files.isRegularFile(filePath)){
                    String extension = "";
                    int i = filePath.getFileName().toString().lastIndexOf('.');
                    if (i > 0) {
                        extension = filePath.getFileName().toString().substring(i+1);
                    }
                    if(Objects.equals(extension, fileending)) {
                        uploadsDidShould++;
                        uploadCounterShould++;
                    }
                }
            });

            Files.walk(Paths.get(path)).forEach(filePath -> {

                if (Files.isRegularFile(filePath)){
                    String extension = "";
                    int i = filePath.getFileName().toString().lastIndexOf('.');
                    if (i > 0) {
                        extension = filePath.getFileName().toString().substring(i+1);
                    }
                    if(Objects.equals(extension, fileending)) {
                        upload(filePath.toString(), watching::onUploaded, watching::onUploadFailed);
                        watching.eventHappened("Upload: " + filePath.toString());
                    }
                } else {
                    System.out.println("Not a Regular File " + filePath);
                }
            });
            watching.onUploaded();
        } catch (Exception e) {
            e.printStackTrace();
            watching.onUploadFailed();
            System.out.println("ordnerHochladen Exception" + e.getMessage());
        }
    }

    /* prüft die internetverbindung (Zugriff auf API : Status) indem status der Verbindung zurückgegeben wird */
    public static void getStatus(ConnectionInterface connection) {

        Unirest.get(statusURL)
                .asStringAsync(new Callback<String>() {

                    public void failed(UnirestException e) {
                        Platform.runLater(connection::noInternetConnection);
                    }

                    public void completed(HttpResponse<String> response) {
                        int code = response.getStatus();
                        if (code == 200) {
                            Platform.runLater(connection::success);
                        } else if (code == 401) {
                            Platform.runLater(connection::wrongKey);
                        }
                    }

                    public void cancelled() {
                        System.out.println("The request has been cancelled");
                    }
                });

    }

}
