package main.components;

import org.joda.time.DateTime;

import java.io.*;

/**
 * Hier werden alle Daten gespeichert
 *
 */
public class Data implements Serializable {


    /* Name der Datei*/
    public static String filename = "martin.share";
    /* Ordner der Datei */
    public static String subDirectory = "Martinshare";


    private boolean showMinimizeNotification = true;
    private String key;
    private String schulname;
    private String homepage;
    private String syncpath = "////";
    private DateTime zuletztAktualisiert;
    //active ist der Zustand des aktualisierens. wenn true dann muss aktualisiert werden
    private boolean active = false;

    public static long serialVersionUID = 82069284762049587L;



    //-------------------------Anfang der Getter und Setter---------------------------------------------------

    public String getKey() {
        return key;
    }
    public static void setKey(String key) {
        Data d = loadData();
        d.key = key;
        writeData(d);
    }

    public String getSchulname() {
        if(schulname == null) return "---";
        return schulname;
    }
    public static void setSchulname(String schulname) {
        Data d = loadData();
        d.schulname = schulname;
        writeData(d);
    }

    public String getHomepage() {
        if(homepage == null) return "--";
        return homepage;
    }
    public static void setHomepage(String homepage) {
        Data d = loadData();
        d.homepage = homepage;
        writeData(d);
    }

    public String getSyncpath() {
        if(syncpath == null) return "-";
        return syncpath;
    }
    public static void setSyncpath(String syncpath) {
        Data d = loadData();
        d.syncpath = syncpath;
        writeData(d);
    }

    public DateTime getZuletztAktualisiert() {
        if(zuletztAktualisiert == null) return new DateTime().withDate(2,2,2);
        return zuletztAktualisiert;
    }
    public static void setZuletztAktualisiert(DateTime zuletztAktualisiert) {
        Data d = loadData();
        d.zuletztAktualisiert = zuletztAktualisiert;
        writeData(d);
    }

    public boolean getActive() {
        return active;
    }

    public static void setActive(boolean active) {
        Data d = loadData();
        d.active = active;
        writeData(d);
    }

    public boolean getShowMinimizeNotification() {
        return showMinimizeNotification;
    }

    public static void setShowMinimizeNotification(boolean showMinimizeNotification) {
        Data d = loadData();
        d.showMinimizeNotification = showMinimizeNotification;
        writeData(d);
    }

    //-------------------------Getter und Setter Ende------------------------------------


    /* Datei wird Gespeichert */
    public static void writeData(Data e) {
        try {
            FileOutputStream fos = new FileOutputStream(getAppDataDirectory(true)+filename);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(e);
            fos.close();
        } catch(IOException i) {
            System.out.println( i.getMessage() + "writeData Exception");
        }
    }

    /* Datei wird Geladen */
    public static Data loadData() {
        if(!new File(getAppDataDirectory(true)+filename).exists()) {
            writeData(new Data());
        }
        try {
            Data data;
            FileInputStream fileIn = new FileInputStream(getAppDataDirectory(true)+filename);
            ObjectInputStream in = new ObjectInputStream(fileIn);
            data = (Data) in.readObject();
            in.close();
            return data;
        } catch(IOException ignore) {
            System.out.println("loadData IOEXCEPTION");
            return new Data();
        } catch(ClassNotFoundException ignore) {
            System.out.println("loadData CLASSNOTFOUNDEXCEPTION");
            return new Data();
        }
    }


    /* Gibt das Verzeichnis der zu speichernden Datei zurück */
    public static String getAppDataDirectory(boolean create) {
        String appDataDirectory;
        try {
            appDataDirectory = System.getenv("APPDATA"); //Windows
            if (appDataDirectory != null) {
                appDataDirectory += File.separator + subDirectory + File.separator;
            } else { //appDataDirectory is null
                appDataDirectory = System.getenv("HOME"); //Unix
                if (appDataDirectory != null) {
                    appDataDirectory +=  File.separator + subDirectory + File.separator;
                } else { //appDataDirectory is still null
                    throw new Exception("Could not access APPDATA or HOME environment variables");
                }
            }
        }
        catch(Exception e) {
            e.printStackTrace();
            appDataDirectory = "";
        }

        if (create && appDataDirectory.length() > 0) {
            try {
                File dir = new File(appDataDirectory);
                dir.mkdir();
            }
            catch(Exception e) {
                e.printStackTrace();
            }
        }
        //System.out.println("appDataDirectory: " + appDataDirectory);
        return appDataDirectory;
    }


}

