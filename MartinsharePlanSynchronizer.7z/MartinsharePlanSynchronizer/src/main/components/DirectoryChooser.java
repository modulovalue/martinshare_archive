package main.components;

import javax.swing.*;

/**
 * Created by Modestas Valauskas on 21.05.2015.
 */
public class DirectoryChooser {

    public static String getDirectory() {
        JFileChooser f = new JFileChooser();
        f.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        f.showSaveDialog(null);
        System.out.println("Current Verzeichnis: "+f.getCurrentDirectory());
        if(f.getSelectedFile() != null) {
            return f.getSelectedFile().getAbsolutePath();
        }

        return "Nichts Ausgewählt";
    }
}
