package main.components;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import main.MartinshareAPI;
import org.apache.http.HttpHost;

import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.ProxySelector;
import java.net.URI;
import java.util.List;

/**
 * Created by Modestas Valauskas on 06.05.2015.
 */
public class GetProxy {

    /* prüft ob proxy vorhanden */
    public static boolean hasProxy() {
        try {
            List l = ProxySelector.getDefault().select(new URI("http://www.google.com/"));

            for (Object aL : l) {
                Proxy proxy = (Proxy) aL;
                InetSocketAddress addr = (InetSocketAddress) proxy.address();
                return addr != null;
            }
        } catch (Exception e) {
            System.err.println("hasProxy Exception" + e.getMessage());
        }
        return false;
    }

    /* gibt den Proxy (HTTPHOST) zurück */
    public static HttpHost getProxy() {
        HttpHost proxyData = null;
        try {
            System.setProperty("java.net.useSystemProxies","true");
            List l = ProxySelector.getDefault().select(new URI("http://www.google.com/"));

            for (Object aL : l) {
                Proxy proxy = (Proxy) aL;
                InetSocketAddress addr = (InetSocketAddress) proxy.address();
                proxyData = new HttpHost(addr.getHostName(), addr.getPort());
            }
        } catch (Exception e) {
            System.err.println("Proxy getProxy Exception");
        }
        return proxyData;
    }

    public static void setProxyConnection() {
        //int status = MartinshareAPI.getStatus();
       // if(status != 200) {
            if(GetProxy.hasProxy()) {
                HttpHost httpHost = GetProxy.getProxy();
                Unirest.setProxy(httpHost);
                System.out.println(httpHost.getHostName() + " " + httpHost.getPort());
            } else {
                Unirest.setProxy(null);
                System.out.println("Kein Proxy erkannt");
            }
       // }
    }
}
