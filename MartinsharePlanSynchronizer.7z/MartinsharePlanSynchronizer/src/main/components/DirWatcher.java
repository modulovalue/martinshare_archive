package main.components;

import main.components.Data;
import main.components.UploadTimer;
import main.interfaces.onWatching;
import org.apache.commons.io.monitor.FileAlterationListener;
import org.apache.commons.io.monitor.FileAlterationListenerAdaptor;
import org.apache.commons.io.monitor.FileAlterationMonitor;
import org.apache.commons.io.monitor.FileAlterationObserver;

import javax.swing.*;
import java.io.File;
import java.io.IOException;

/**
 * Created by Modestas Valauskas on 08.04.2015.
 */
public class DirWatcher {

    private FileAlterationObserver observer;
    private FileAlterationMonitor monitor;

    private String path;
    private onWatching watching;

    public DirWatcher(String path, onWatching watching) {
        this.path = path;
        this.watching = watching;

        final long pollingInterval = 1 * 1000;

        observer = new FileAlterationObserver(new File(path));
        observer.addListener(new FileAlterationListenerAdaptor() {

            @Override
            public void onStart(FileAlterationObserver fileAlterationObserver) {
                watching.startWatching();
            }

            @Override
            public void onFileCreate(File file) {
                try {
                    System.out.println("Datei wurde erstellt: " + file.getCanonicalPath());
                    UploadTimer.uploadWholeDirectoryTimer(path, watching);
                    watching.eventHappened("File created: " + file.getAbsolutePath());
                } catch (IOException e) {
                    e.printStackTrace(System.err);
                }
            }

            @Override
            public void onFileChange(File file) {
                try {
                    System.out.println("Datei wurde verändert " + file.getCanonicalPath());
                    UploadTimer.uploadWholeDirectoryTimer(path, watching);
                    watching.eventHappened("File changed: " + file.getAbsolutePath());
                } catch (IOException e) {
                    e.printStackTrace(System.err);
                }
            }

            @Override
            public void onFileDelete(File file) {
                try {
                    System.out.println("Datei wurde gelöscht " + file.getCanonicalPath());
                    UploadTimer.uploadWholeDirectoryTimer(path, watching);
                    watching.eventHappened("File deleted: " +file.getAbsolutePath());
                } catch (IOException e) {
                    e.printStackTrace(System.err);
                }
            }

            @Override
            public void onStop(FileAlterationObserver fileAlterationObserver) {
                watching.stopWatching();
            }
        });

        monitor = new FileAlterationMonitor(pollingInterval);

        try {
            monitor.start();
            System.out.println("START WATCHING CALLED Monitor gestartet" + path);
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, "Watcher Monitor Exception " + e.getLocalizedMessage());
        }
    }

    public void startWatching() {
        System.out.println("START WATCHING CALLED");
        monitor.removeObserver(observer);
        monitor.addObserver(observer);
        watching.startedWatching();
    }

    public void stopWatching() {
        System.out.println("STOP WATCHING CALLED");
        if(monitor != null) {
            monitor.removeObserver(observer);
        }
        watching.stoppedWatching();
    }
}
