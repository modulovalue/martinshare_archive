package main.components;

import javafx.application.Platform;
import javafx.scene.control.*;
import main.Main;
import main.MartinshareAPI;
import main.interfaces.ConnectionDeleteInterface;
import main.interfaces.onWatching;
import org.joda.time.DateTime;

import java.awt.*;
import java.util.Timer;
import java.util.TimerTask;
import java.util.function.Function;

/**
 * Created by Modestas Valauskas on 21.05.2015.
 */
public class UploadTimer {

    private static Timer timer, timerTest;

    /*
    * Da beim Beobachten des Ordners verschiedene Dinge erkannt werden (Umbenennen, Erstellen,...),
    * werden viele Events abgefeuert.
    * Ein Timer wird gestartet der 3 sek wartet bis keine Veränderungen mehr kommen.
    * Erst dann, werden alle Dateien des Ordners hochgeladen
    */

    private static int zeit = 3;
    public static void uploadWholeDirectoryTimer( String path, onWatching watching) {
        if (timer == null) {
            timer = new Timer();
            watching.startUploading();
            timer.schedule(new TimerTask() {
                @Override
                public void run() {
                    MartinshareAPI.serverDelete(new ConnectionDeleteInterface() {
                        @Override
                        public void noInternetConnection() {
                            Main.getInstance().trayIcon.displayMessage("Keine Internetverbindung", "Aktualisierung erfolgt erneut in 3 Sekunden", TrayIcon.MessageType.ERROR);
                            timer = null;
                            UploadTimer.uploadWholeDirectoryTimer(path, watching);
                        }

                        @Override
                        public void zuletztAktualisiert() {

                            Main.getInstance().trayIcon.displayMessage("Aktualisierung", "Pläne wurden vor Kurzem aktualisiert. Aktualisierung erfolgt erneut in 3 Sekunden", TrayIcon.MessageType.INFO);
                            timer = null;
                            UploadTimer.uploadWholeDirectoryTimer(path, watching);
                        }

                        @Override
                        public void success() {
                            MartinshareAPI.ordnerHochladen(path, watching);
                            timer = null;
                        }

                        @Override
                        public void wrongKey() {

                        }
                    });
                }
            }, zeit*1000);
        }
    }
}
