package main.components;

/**
 * Created by Modestas Valauskas on 11.04.2015.
 */
public class Info {

    public final static String version = "1.0";
    public final static String homepage = "http://www.martinshare.com";
    public final static String contact = "info@martinshare.com";

}
