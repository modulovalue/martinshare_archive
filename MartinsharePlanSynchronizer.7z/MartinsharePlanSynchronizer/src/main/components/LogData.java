package main.components;

import main.Main;
import org.apache.commons.io.FileUtils;
import org.joda.time.DateTime;

import java.io.File;
import java.io.IOException;

/**
 * Created by Modestas Valauskas on 21.05.2015.
 */
public class LogData {

    private static String logfilename = "martinsharelog.txt";
    public static void writeLogFile(String write) {

        if(Main.getInstance().DEBUG) {
            try {
                FileUtils.writeStringToFile(new File(Data.getAppDataDirectory(true) + logfilename), DateTime.now() + ": " + write + System.getProperty("line.separator"), true);
            } catch (IOException i) {
                System.out.println(i.getMessage() + "writeData Exception");
            }
        }

    }

    public static void deleteLogFile() {
        try {
            FileUtils.writeStringToFile(new File(Data.getAppDataDirectory(true)+logfilename),"-", false);
        } catch(IOException i) {
            System.out.println( i.getMessage() + "writeData Exception");
        }
    }

    public static String readLogFile() {
        try {
            return FileUtils.readFileToString(new File(Data.getAppDataDirectory(true)+logfilename));
        } catch(IOException i) {
            System.out.println( i.getMessage() + "writeData Exception");
        }
            return "Can't read Logfile";
    }
}
