package main;

import com.mashape.unirest.http.Unirest;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.scene.image.Image;
import javafx.stage.Stage;

import main.components.Data;
import main.components.LogData;
import main.windows.log.LogWindow;
import main.windows.login.LoginWindow;
import main.windows.main.MainWindow;
import main.windows.test.TestWindow;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;

public class Main extends Application {


    public final boolean DEBUG = false;

    private static Main instance;
    public TrayIcon trayIcon;
    public Stage window;
    public LoginWindow loginWindow;
    public MainWindow mainWindow;

    public TestWindow testWindow;
    public LogWindow logWindow;

    public static Main getInstance() { return instance; }

    public static void main(String[] args) {
        System.setProperty("java.net.useSystemProxies","true");

        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        instance = this;
        Platform.setImplicitExit(false);
        window = primaryStage;
        window.setResizable(false);
        window.getIcons().add(new Image("images/icon.png"));
        window.setTitle("Martinshare PS");

        if(Data.loadData().getKey() == null) {
            showLogin();
        } else {
            showMain();
        }

        if(DEBUG) {
            Platform.runLater(() ->  {
                logWindow = new LogWindow();
                Stage stage = new Stage();
                stage.setScene(logWindow.getScene());
                stage.setX(0);
                stage.setY(0);
                stage.show();

                testWindow = new TestWindow();
                Stage stage2 = new Stage();
                stage2.setScene(testWindow.getScene());
                stage2.setY(450);
                stage2.setX(0);
                stage2.show();
            });
        }
    }

    public void showLogin() {
        loginWindow = new LoginWindow();
        hideTray();
        window.setOnCloseRequest(e -> {
            Platform.exit();
            System.exit(0);
        });
        window.setScene(loginWindow.getScene());
        window.show();
    }

    public void showMain() {
        if(mainWindow == null) {
            mainWindow = new MainWindow();
        }

        showTray();
        window.iconifiedProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> prop, Boolean oldValue, Boolean newValue) {
                window.setIconified(false);
                hideMain(window);
            }
        });

        mainWindow.controller.updateUI();
        window.setOnCloseRequest(t -> {
            t.consume();
            hideMain(window);
        });
        window.setScene(mainWindow.getScene());
        window.show();
    }



    /* Das SystemTray Icon wird angezeigt */
    public void showTray() {

        try {
            UIManager.setLookAndFeel( UIManager.getSystemLookAndFeelClassName());
        } catch (UnsupportedLookAndFeelException | ClassNotFoundException | InstantiationException | IllegalAccessException f) { }

        if (SystemTray.isSupported() && trayIcon == null) {
            PopupMenu popup = new PopupMenu();
            MenuItem defaultItem;

//            if(DEBUG) {
//
//                defaultItem = new MenuItem("Test Window");
//                defaultItem.addActionListener(e -> {
//                    Platform.runLater(() ->  {
//                        testWindow = new TestWindow();
//                        Stage stage = new Stage();
//                        stage.setScene(testWindow.getScene());
//                        stage.show();
//                    });
//                });
//                popup.add(defaultItem);
//
//            }

            defaultItem = new MenuItem("Öffnen");
            defaultItem.addActionListener(e -> {
                Platform.runLater(() -> show(window));
            });
            popup.add(defaultItem);

            popup.addSeparator();

            defaultItem = new MenuItem("Schließen");
            defaultItem.addActionListener(e -> {
                exitDialog();
            });
            popup.add(defaultItem);

            trayIcon = new TrayIcon(Toolkit.getDefaultToolkit().getImage("images/icon.png"), "Martinshare PS", popup);
            trayIcon.setImageAutoSize(true);

            trayIcon.addMouseListener(new MouseAdapter() {
                public void mouseClicked(MouseEvent e) {
                    if (e.getClickCount() == 2) {
                        if(window.isShowing()) {
                            hideMain(window);
                        } else {
                            show(window);
                        }
                    }
                }
            });
            try {
                SystemTray.getSystemTray().add(trayIcon);
            } catch (AWTException e) {
                System.err.println(e);
            }
        }
    }


    /* Das SystemTrayIcon wird versteckt */
    public Main hideTray() {
        SystemTray.getSystemTray().remove(trayIcon);
        trayIcon = null;
        return this;
    }

    public void hideMain(final Stage stage) {
        Platform.runLater(() -> {
            if(Data.loadData().getActive() && Data.loadData().getShowMinimizeNotification()) {
                trayIcon.displayMessage("Martinshare PS", "Die Aktualisierung von: "+Data.loadData().getSyncpath()+" läuft im Hintergrund weiter.", TrayIcon.MessageType.INFO);
            }
            stage.hide();
        });

    }

    private void show(final Stage stage) {
        Platform.runLater(() -> {
                stage.show();
        });
    }

    /* Anders als die anderen Fenster, wird dieser Bestätigungsdialog mit Swing umgesetzt */
    public void exitDialog() {
        String ObjButtons[] = {"Ja","Nein"};
        int PromptResult = JOptionPane.showOptionDialog(null, "Sind Sie sicher, dass Sie Martinshare PS beenden wollen?", "Schließen", JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE, null,  ObjButtons,ObjButtons[1]);
        if(PromptResult==0) {
            try {
                Unirest.shutdown();
            } catch (IOException e) {
                e.printStackTrace();
            }
            System.exit(0);
        }
    }
}
