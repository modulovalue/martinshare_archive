package main.interfaces;

/**
 * Created by Modestas Valauskas on 08.04.2015.
*/
public interface ConnectionInterface {
    public void noInternetConnection();
    public void success();
    public void wrongKey();
}

