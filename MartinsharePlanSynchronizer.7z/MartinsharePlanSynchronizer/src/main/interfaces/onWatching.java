package main.interfaces;

/**
 * Created by Modestas Valauskas on 08.04.2015.
 */
public interface onWatching {
    //Beobachten hat begonnen
    public void startedWatching();
    //Ein Scan hat begonnen
    public void startWatching();
    //Ein Scan ist durchgelaugen
    public void stopWatching();
    //Beobachten wurde gestoppt
    public void stoppedWatching();
    public void startUploading();
    public void onUploaded();
    public void onUploadFailed();
    public void eventHappened(String string);

}
