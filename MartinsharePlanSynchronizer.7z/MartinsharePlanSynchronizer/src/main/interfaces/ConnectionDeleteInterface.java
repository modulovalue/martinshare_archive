package main.interfaces;


public interface ConnectionDeleteInterface {
    public void noInternetConnection();
    public void zuletztAktualisiert();
    public void success();
    public void wrongKey();
}
